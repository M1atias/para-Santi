package com.example.ejemplo1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejemplo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
